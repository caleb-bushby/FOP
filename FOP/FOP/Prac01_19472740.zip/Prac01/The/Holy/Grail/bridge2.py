#
# bridge.py - a scene from The Holy Grail
#
print("\nWelcome to the Bridge of Death\n")
name = input("What is your name?")
quest = input("What is your quest?")
colour = input("What is your favourite colour?")
print("\nHello,", name, "Good luck with your", quest, "quest!")
print("Perhaps wearing", colour, "socks would help :)\n")
